var http = require('http');
var express = require('express');
var app = express();

app.get('/', function(req, res){
    res.sendfile('index.html');
});
app.get('/table', function(req, res){
    res.sendfile('table.html');
});
app.get('/disk', function(req, res){
    res.sendfile('disk.html');
});
app.get('/math', function(req, res){
    res.sendfile('numbers.html');
});

app.listen(9090);
